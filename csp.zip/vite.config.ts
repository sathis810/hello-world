import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import cryptoRandomString from 'crypto-random-string';

// Generate a nonce for each build
const nonce = cryptoRandomString({length: 16, type: 'base64'});

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react(),
    {
      name: 'html-transform',
      transformIndexHtml(html) {
        return html.replace(/%%NONCE%%/g, nonce);
      },
    },
  ],
  define: {
    'process.env.NONCE': JSON.stringify(nonce),
  },
  optimizeDeps: {
    exclude: ['lucide-react'],
  },  
  build: {
    sourcemap: true,
  },
});