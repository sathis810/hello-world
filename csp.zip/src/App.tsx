import React, { useState, useEffect } from 'react';
import { Shield } from 'lucide-react';
import cryptoRandomString from 'crypto-random-string';

const nonce = process.env.NONCE;

console.log(`The nonce value is: ${nonce}`);

function App() {
  const [message, setMessage] = useState('');

  useEffect(() => {

    // Sample HTML string with CSP validations
    var sampleHTML = `
    <div>
    <style nonce='${nonce}'> .csp { color: blue; font-weight: bold; }</style>
      <div>
        <p class="csp">This is a sample HTML string with CSP validations from style tag.</p>        
      </div>
      </div>
    `;

    const parser = new DOMParser();
    const doc = parser.parseFromString(sampleHTML, 'text/html');
    document.getElementById('csp-container')?.appendChild(doc.body);

    var sampleHTML = `
    <div>
      <div style="color: blue; font-weight: bold;">
        <p>This is a sample HTML string with CSP validations from div style.</p>        
      </div>
      <div style="color: red; font-weight: bold;">
        <p>This is a sample HTML string with CSP validations from div style.</p>        
      </div>
      </div>
    `;

    sampleHTML = moveDivStylesToStyleTag(sampleHTML, nonce);

    const doc1 = parser.parseFromString(sampleHTML, 'text/html');
    document.getElementById('csp-container-2')?.appendChild(doc1.body);


    setMessage('CSP is working!');
  }, [nonce]);

  function moveDivStylesToStyleTag(htmlString, nonce) {
    // Create a temporary DOM element to parse the HTML string
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlString, "text/html");
    const divs = doc.querySelectorAll("div[style]");
  
    if (divs.length === 0) {
      return htmlString; // No divs with styles, return original string
    }
  
    // Collect styles and generate unique class names
    let styleContent = "";
    divs.forEach((div) => {
      const randomStr = cryptoRandomString({length: 10, type: 'alphanumeric'});
      const inlineStyle = div.getAttribute("style");
      if (inlineStyle) {
        // Generate a unique class name (e.g., div-style-0, div-style-1)
        const className = `csp-style-${randomStr}`;
        styleContent += `.${className} { ${inlineStyle} }\n`;
        // Replace the style attribute with the class
        div.removeAttribute("style");
        div.classList.add(className);
      }
    });
  
    // Create the <style> tag with the nonce and collected styles
    const styleTag = `<style nonce="${nonce}">\n${styleContent}</style>`;
  
    // Insert the <style> tag before the first div in the body
    const bodyContent = doc.body.innerHTML;
    const modifiedHTML = `
      <div>
        ${styleTag}
        ${bodyContent}
      </div>
    `;
  
    return modifiedHTML.trim(); // Return the cleaned-up HTML string
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-4xl mx-auto p-8">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center gap-3 mb-6">
            <Shield className="w-8 h-8 text-green-600" />
            <h1 className="text-2xl font-bold">Content Security Policy Demo</h1>
          </div>

          {/* Example of inline style with hash */}
          <p style={{ color: 'blue', fontWeight: 'bold' }} className="mb-4">
            This style is allowed via hash
          </p>

          {/* Example of nonce-based style */}
          <p nonce={nonce} style={{ color: 'green', fontStyle: 'italic' }} className="mb-4">
            This style is allowed via nonce
          </p>

          {/* Example of nonce-based style */}
          <p style={{ color: 'green', fontStyle: 'italic' }} className="mb-4">
            This style is allowed via nonce
          </p>

          <div className="bg-gray-50 p-4 rounded-md">
            <h2 className="text-lg font-semibold mb-2">CSP Status</h2>
            <p className="text-green-600">{message}</p>
          </div>
          <div id="csp-container"></div>
          <div id="csp-container-2"></div>
        </div>
      </div>
    </div>
  );
}

export default App;